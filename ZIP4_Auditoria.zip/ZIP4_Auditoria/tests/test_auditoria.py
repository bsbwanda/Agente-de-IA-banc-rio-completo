def test_auditoria():
    assert True
