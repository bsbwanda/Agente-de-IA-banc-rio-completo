# Auditoria

Campos registrados:
- usuario
- operacao
- detalhes
- ip
- data_hora

Operacoes monitoradas:
- saldo
- deposito
- transferencia
