# ZIP 4 - Auditoria

Implementa trilha de auditoria para operações bancárias.

Recursos:
- Registro de usuário
- Operação executada
- Data/hora
- IP de origem
- Consulta de auditoria
