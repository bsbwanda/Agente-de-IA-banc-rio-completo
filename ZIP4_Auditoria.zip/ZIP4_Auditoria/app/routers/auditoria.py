from fastapi import APIRouter

router = APIRouter(prefix="/auditoria", tags=["Auditoria"])

@router.get("/")
def listar_logs():
    return {
        "mensagem": "Endpoint de auditoria ativo"
    }
