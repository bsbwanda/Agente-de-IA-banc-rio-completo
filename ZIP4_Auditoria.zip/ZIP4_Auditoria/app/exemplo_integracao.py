# Exemplo de uso
# registrar(db, "admin", "deposito", "Deposito de 100", "127.0.0.1")
