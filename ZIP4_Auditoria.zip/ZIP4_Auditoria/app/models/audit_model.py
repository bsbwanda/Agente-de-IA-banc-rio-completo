from sqlalchemy import Column,Integer,String,DateTime
from sqlalchemy.sql import func
from app.database.database import Base

class Auditoria(Base):
    __tablename__ = "auditoria"
    id = Column(Integer, primary_key=True)
    usuario = Column(String)
    operacao = Column(String)
    detalhes = Column(String)
    ip = Column(String)
    data = Column(DateTime(timezone=True), server_default=func.now())
