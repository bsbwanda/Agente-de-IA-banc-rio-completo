from app.models.audit_model import Auditoria

def registrar(db,usuario,operacao,detalhes,ip):
    log = Auditoria(
        usuario=usuario,
        operacao=operacao,
        detalhes=detalhes,
        ip=ip
    )
    db.add(log)
    db.commit()
