from app.agents.restrictive_agent import processar

def test_bloqueia_bitcoin():
    assert "erro" in processar("o que é bitcoin")

def test_saldo():
    assert processar("consultar saldo")['operacao']=='saldo'
