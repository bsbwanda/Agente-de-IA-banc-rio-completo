# ZIP 5 - IA Restrita (Anti-Alucinação)

Funcionalidades:
- Classificação de intenção
- Bloqueio de assuntos fora do escopo
- Guardrails
- Log de tentativas inválidas
- Preparação para N8N

Operações permitidas:
- saldo
- deposito
- transferencia
