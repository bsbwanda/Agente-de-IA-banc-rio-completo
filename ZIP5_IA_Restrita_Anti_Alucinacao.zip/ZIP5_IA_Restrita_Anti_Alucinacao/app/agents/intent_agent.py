OPERACOES=["saldo","deposito","transferencia"]

def detectar_intencao(texto:str):
    t=texto.lower()
    if "saldo" in t: return "saldo"
    if "deposit" in t: return "deposito"
    if "transfer" in t: return "transferencia"
    return None
