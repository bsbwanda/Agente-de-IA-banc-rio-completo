from app.agents.intent_agent import detectar_intencao
from app.guardrails.policy import validar,MSG
from app.guardrails.invalid_log import registrar_tentativa

def processar(texto):
    intent=detectar_intencao(texto)
    if not validar(intent):
        registrar_tentativa(texto)
        return {"erro":MSG}
    return {"operacao":intent}
