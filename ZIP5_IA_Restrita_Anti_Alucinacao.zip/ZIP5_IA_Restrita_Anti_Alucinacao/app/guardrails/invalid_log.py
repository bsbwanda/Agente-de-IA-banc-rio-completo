from datetime import datetime

def registrar_tentativa(texto):
    with open("tentativas_invalidas.log","a",encoding="utf-8") as f:
        f.write(f"{datetime.now()} | {texto}
")
