MSG="Desculpe, posso auxiliar apenas com saldo, transferência e depósito."

def validar(intencao):
    return intencao in ["saldo","deposito","transferencia"]
