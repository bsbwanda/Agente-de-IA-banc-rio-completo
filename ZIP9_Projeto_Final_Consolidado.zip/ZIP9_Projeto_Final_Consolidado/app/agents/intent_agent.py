def detectar(texto):
 t=texto.lower()
 return "saldo" if "saldo" in t else "deposito" if "deposit" in t else "transferencia" if "transfer" in t else None