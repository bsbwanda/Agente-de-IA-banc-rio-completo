from fastapi import FastAPI
app=FastAPI(title="Projeto Final")
@app.get("/")
def root(): return {"status":"ok"}