from jose import jwt
from datetime import datetime,timedelta
SECRET_KEY="super-secret-key"
ALGORITHM="HS256"
def create_token(username:str):
    return jwt.encode({"sub":username,"exp":datetime.utcnow()+timedelta(hours=1)},SECRET_KEY,algorithm=ALGORITHM)
