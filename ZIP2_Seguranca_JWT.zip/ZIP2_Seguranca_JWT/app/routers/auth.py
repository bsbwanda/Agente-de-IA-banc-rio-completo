from fastapi import APIRouter,HTTPException
from app.models.user import UserCreate
from app.security.hash import hash_password,verify_password
from app.security.auth import create_token
router=APIRouter(prefix="/auth",tags=["Auth"])
USERS={}
@router.post("/register")
def register(user:UserCreate):
    USERS[user.username]=hash_password(user.password)
    return {"message":"usuario criado"}
@router.post("/login")
def login(user:UserCreate):
    if user.username not in USERS or not verify_password(user.password,USERS[user.username]):
        raise HTTPException(401,'credenciais invalidas')
    return {"access_token":create_token(user.username),"token_type":"bearer"}
