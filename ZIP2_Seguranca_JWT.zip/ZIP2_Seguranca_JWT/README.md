# ZIP 2 - JWT e Autenticacao

Execute: uvicorn app.main:app --reload