# ZIP 7 - Testes e Cobertura > 80%

Inclui estrutura de testes automatizados com Pytest e cobertura usando pytest-cov.
