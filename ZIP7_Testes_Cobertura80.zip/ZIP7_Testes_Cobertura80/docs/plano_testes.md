# Plano de Testes

Cobertura desejada: > 80%

Casos:
- Saldo
- Deposito
- Transferencia
- Bloqueio fora de escopo
- Integracao API
