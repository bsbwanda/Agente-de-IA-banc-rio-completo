from app.agents.restrictive_agent import processar

def test_bloqueio():
    assert 'erro' in processar('bitcoin')
