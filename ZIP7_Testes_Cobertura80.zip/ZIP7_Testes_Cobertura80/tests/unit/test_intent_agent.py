from app.agents.intent_agent import detectar_intencao

def test_saldo():
    assert detectar_intencao("consultar saldo") == "saldo"

def test_deposito():
    assert detectar_intencao("depositar 100") == "deposito"

def test_transferencia():
    assert detectar_intencao("transferir 50") == "transferencia"
