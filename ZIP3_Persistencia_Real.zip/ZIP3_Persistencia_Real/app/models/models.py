from sqlalchemy import Column,Integer,String,Float,ForeignKey,DateTime
from sqlalchemy.sql import func
from app.database.database import Base
class Usuario(Base):
 __tablename__="usuarios"
 id=Column(Integer,primary_key=True)
 username=Column(String,unique=True)
 senha=Column(String)
class Conta(Base):
 __tablename__="contas"
 id=Column(Integer,primary_key=True)
 titular=Column(String)
 saldo=Column(Float,default=0)
class Transacao(Base):
 __tablename__="transacoes"
 id=Column(Integer,primary_key=True)
 tipo=Column(String)
 valor=Column(Float)
 conta_origem=Column(Integer,nullable=True)
 conta_destino=Column(Integer,nullable=True)
 data=Column(DateTime,timezone=True,server_default=func.now())
