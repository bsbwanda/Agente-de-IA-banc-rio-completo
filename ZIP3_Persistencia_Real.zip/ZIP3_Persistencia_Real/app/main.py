from fastapi import FastAPI
from app.database.database import Base,engine,SessionLocal
from app.models.models import Conta
from app.routers.contas import router
Base.metadata.create_all(bind=engine)
app=FastAPI(title="ZIP3 Persistencia")
app.include_router(router)
@app.on_event("startup")
def seed():
 db=SessionLocal()
 if not db.query(Conta).first():
  db.add(Conta(id=1,titular="Conta Teste",saldo=1000))
  db.commit()
 db.close()
