from app.models.models import Conta,Transacao
class BancoService:
 @staticmethod
 def depositar(db,conta_id,valor):
  c=db.query(Conta).filter(Conta.id==conta_id).first()
  if not c:return None
  c.saldo+=valor
  db.add(Transacao(tipo="deposito",valor=valor,conta_destino=conta_id))
  db.commit();return c
