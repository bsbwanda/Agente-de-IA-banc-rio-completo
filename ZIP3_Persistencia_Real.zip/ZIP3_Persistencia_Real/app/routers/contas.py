from fastapi import APIRouter
router=APIRouter(prefix="/contas",tags=["Contas"])
@router.get("/")
def listar():
 return {"mensagem":"persistencia ativa"}
