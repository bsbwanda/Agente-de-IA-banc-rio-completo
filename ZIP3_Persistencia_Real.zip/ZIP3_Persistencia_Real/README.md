# ZIP 3 - Persistência Real

Implementa persistência com SQLite e SQLAlchemy.

Recursos:
- Usuários
- Contas
- Transações
- Histórico
- Seed inicial
