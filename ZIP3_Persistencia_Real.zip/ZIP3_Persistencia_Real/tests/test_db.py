from app.database.database import Base
def test_import():
 assert Base is not None
