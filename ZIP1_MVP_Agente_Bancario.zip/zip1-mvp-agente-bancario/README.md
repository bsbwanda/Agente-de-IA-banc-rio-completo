# ZIP 1 - MVP Agente Bancário

Funcionalidades:
- Consulta de saldo
- Depósito
- Transferência
- SQLite
- FastAPI
- Swagger
- Docker

Executar:

```bash
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Swagger:
http://localhost:8000/docs
