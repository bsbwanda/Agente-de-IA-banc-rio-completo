from fastapi import FastAPI,HTTPException
from sqlalchemy.orm import Session
from app.database import Base,engine,SessionLocal
from app.models import Conta

Base.metadata.create_all(bind=engine)
app=FastAPI(title="Agente Bancario MVP")

@app.get('/')
def health():
    return {'status':'online'}

@app.get('/saldo/{conta_id}')
def saldo(conta_id:int):
    db=SessionLocal()
    c=db.query(Conta).filter(Conta.id==conta_id).first()
    if not c: raise HTTPException(404,'Conta não encontrada')
    return {'conta':c.id,'saldo':c.saldo}

@app.post('/deposito')
def deposito(conta_id:int,valor:float):
    db=SessionLocal()
    c=db.query(Conta).filter(Conta.id==conta_id).first()
    if not c:
        c=Conta(id=conta_id,titular='Cliente',saldo=0)
        db.add(c)
    c.saldo+=valor
    db.commit()
    return {'saldo':c.saldo}

@app.post('/transferencia')
def transferencia(origem:int,destino:int,valor:float):
    db=SessionLocal()
    o=db.query(Conta).filter(Conta.id==origem).first()
    d=db.query(Conta).filter(Conta.id==destino).first()
    if not o or not d: raise HTTPException(404,'Conta não encontrada')
    if o.saldo<valor: raise HTTPException(400,'Saldo insuficiente')
    o.saldo-=valor
    d.saldo+=valor
    db.commit()
    return {'status':'ok'}
