# Manual de Instalação
pip install -r requirements.txt
uvicorn app.main:app --reload
Acessar: http://localhost:8000/docs
