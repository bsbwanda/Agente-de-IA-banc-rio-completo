# Arquitetura
Frontend/N8N -> FastAPI -> Services -> SQLite

Camadas:
- API
- Agentes IA
- Serviços
- Persistência
- Auditoria
