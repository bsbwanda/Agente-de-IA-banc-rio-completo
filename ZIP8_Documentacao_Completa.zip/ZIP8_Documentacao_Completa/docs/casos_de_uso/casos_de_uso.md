# Casos de Uso
UC01 - Login
UC02 - Consultar Saldo
UC03 - Realizar Depósito
UC04 - Realizar Transferência
UC05 - Consultar Auditoria
