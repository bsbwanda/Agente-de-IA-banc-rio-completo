# Requisitos Não Funcionais
RNF01 - API REST FastAPI
RNF02 - Banco SQLite
RNF03 - Autenticação JWT
RNF04 - Docker
RNF05 - Cobertura de testes > 80%
RNF06 - Tempo médio de resposta inferior a 2 segundos
