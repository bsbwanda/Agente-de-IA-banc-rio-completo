# Requisitos Funcionais
RF01 - Autenticar usuário via JWT
RF02 - Consultar saldo
RF03 - Realizar depósito
RF04 - Realizar transferência
RF05 - Registrar auditoria
RF06 - Exibir documentação Swagger
RF07 - Integrar com N8N
