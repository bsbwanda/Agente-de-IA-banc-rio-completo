# Importação N8N
1. Abrir N8N
2. Importar workflow.json
3. Configurar URL da API FastAPI
4. Executar testes
