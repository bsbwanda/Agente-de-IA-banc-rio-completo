from fastapi import FastAPI
from app.webhooks.n8n_receiver import router
app=FastAPI(title="N8N Integration")
app.include_router(router)
