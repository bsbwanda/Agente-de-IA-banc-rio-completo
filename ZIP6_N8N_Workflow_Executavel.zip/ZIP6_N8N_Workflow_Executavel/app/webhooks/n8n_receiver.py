from fastapi import APIRouter
router=APIRouter(prefix="/webhook",tags=["N8N"])
@router.post("/n8n")
def receber(payload:dict):
    return {"received":True,"payload":payload}
