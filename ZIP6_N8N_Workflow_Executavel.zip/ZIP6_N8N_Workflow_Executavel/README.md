# ZIP 6 - N8N + Workflow Executável

Recursos:
- Webhook N8N
- Fluxo de saldo
- Fluxo de depósito
- Fluxo de transferência
- Integração FastAPI
- Tratamento de erros
- Auditoria preparada
